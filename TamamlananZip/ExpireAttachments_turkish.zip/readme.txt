[center][size=18pt][b]Bu Dil Paketi Bir smf.konusal.com hizmetidir[/b][/size][/center]
[center][size=14pt][color=green][b][url=http://smf.konusal.com/]Smf destek[/url][/b][/color][/size]


[img]http://smf.konusal.com/Themes/pisi/images/theme/logo.png[/img][/center]