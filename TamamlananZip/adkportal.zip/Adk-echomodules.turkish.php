<?php
/**
 * Adk Portal
 * Version: 3.0
 * Official support: http://www.smfpersonal.net
 * Author: Adk Team
 * Copyright: 2009 - 2014 � SMFPersonal
 * Developers:
 * 		Juarez, Lucas Javier
 * 		Clavijo, Pablo
 *
 * version smf 2.0*
 *t�k�e �eviri: http://smf.konusal.com/
 */

$txt['adkmodules_shouts'] = 'Sohbet Kutusu Mesajlar';
$txt['adkmodules_autor'] = 'Yazar';
$txt['adkmodules_date'] = 'Tarih';
$txt['adkmodules_credits'] = 'SMF - ADK Ki�isel Portal';
$txt['adkmodules_email'] = 'E-mail';
$txt['adkmodules_name'] = '�sim';
$txt['adkmodules_remove_message'] = 'Bu �letiyi silmek istiyor musunuz? Bu i�lem geri Al�namaz';
$txt['adkmodules_credits_01'] = 'K�sa A��klama';
$txt['adkmodules_credits_02'] = '<b>Adk portal</b> birden fazla uzant�lar� ve �zellikleri ile, SMF entegre edilmi�tir.';
$txt['adkmodules_credits_03'] = 'Portal Y�neticisi basit ve sezgisel hedefleniyor.';
$txt['adkmodules_credits_04'] = 'Bu vb indirme b�y�k bir set, i� sayfalar�n sistemi, sahip olman�n yan� s�ra portal t�m �zelliklere sahiptir';
$txt['adkmodules_credits_05'] = 'Kredi';
$txt['adkmodules_credits_06'] = '<b>SMFPersonal</b> want to thank everyone who helped make <b>Adk Portal</b> what is today.';
$txt['adkmodules_credits_07'] = 'To <b>Users</b> by choosing every day.';
$txt['adkmodules_credits_08'] = 'To <b>Translators</b> that they can make reading in the world.';
$txt['adkmodules_credits_09'] = 'To <b>Testers</b> they are restless for errors.';
$txt['adkmodules_credits_10'] = 'To <b>Friends</b> they give us their unconditional support.';
$txt['adkmodules_credits_11'] = 'Staff';
$txt['adkmodules_credits_12'] = '�zel te�ekk�r';
$txt['adkmodules_form_send_content'] = 'Mesaj ��eri�i';
$txt['adkmodules_form_sendeded'] = 'Mesaj g�nderildi. te�ekk�rler';
$txt['adkmodules_form_send_all'] = 'veri g�nderme';
$txt['adkmodules_form_select_admin'] = 'Administrator';
$txt['adkmodules_form_contact'] = '�leti�im Formu';
$txt['adkmodules_index_pages'] = 'Sayfa �ndeksi';
$txt['adkmodules_add_comment'] = 'Yorum ekle';
$txt['adkmodules_comments'] = 'Yorumlar';
$txt['adkmodules_reply'] = 'Cevapla';
$txt['adkmodules_clean_unread'] = 'Temiz okunmam�� yorumlar';
$txt['adkmodules_no_unread'] = 'Okunmam�� Yorumlar';

?>